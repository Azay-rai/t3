import React, { useState } from 'react';


const Signup = ({ handleLoginClick }) => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    let req = new XMLHttpRequest();

    req.open('GET', 'https://api.jsonbin.io/v3/b/66edc259e41b4d34e433f700/latest', true);
    req.setRequestHeader('X-Master-Key', '$2a$10$ToZWzptdp8n/w6Sc1RPpyOhA34hTnX34qphoPoxBjzvGU34Ix8wJC');

    req.onreadystatechange = () => {
      if (req.readyState === XMLHttpRequest.DONE) {
        if (req.status === 200) {
          const binData = JSON.parse(req.responseText);
          const existingData = Array.isArray(binData.record) ? binData.record : [];
          
          // Check for existing user with the same email
          const userExists = existingData.find(user => user.email === formData.email);
          if (userExists) {
            alert('Email already exists. Please use a different email.');
            return;
          }

          const updatedData = [...existingData, formData];

          let updateReq = new XMLHttpRequest();
          updateReq.open('PUT', 'https://api.jsonbin.io/v3/b/66edc259e41b4d34e433f700', true);
          updateReq.setRequestHeader('Content-Type', 'application/json');
          updateReq.setRequestHeader('X-Master-Key', '$2a$10$ToZWzptdp8n/w6Sc1RPpyOhA34hTnX34qphoPoxBjzvGU34Ix8wJC');

          updateReq.onreadystatechange = () => {
            if (updateReq.readyState === XMLHttpRequest.DONE) {
              if (updateReq.status === 200) {
                console.log('Data updated successfully:', updateReq.responseText);
                alert('Signup Successful!'); // Optional: Add a success message
                handleLoginClick(); // Switch to login form after successful signup
              } else {
                console.error('Error updating data:', updateReq.responseText);
                alert('Signup failed. Please try again.');
              }
            }
          };

          updateReq.send(JSON.stringify(updatedData));
        } else {
          console.error('Error fetching data:', req.responseText);
          alert('Could not fetch existing data. Please try again later.');
        }
      }
    };

    req.send();
  };

  return (
    <div className="signup-container">
      <h2 className="text-center">Signup Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Username</label>
          <input
            type="text"
            className="form-control"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
      <button className="btn btn-link" onClick={handleLoginClick}>
        Already have an account? Go to Login
      </button>
    </div>
  );
};

export default Signup;
