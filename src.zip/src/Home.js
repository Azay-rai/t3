import React from 'react';
import { Container, Row, Col, Button, Form } from 'react-bootstrap';
import homeImage from './bnk.png'; // Update the path based on where you place your image
import sideImage from './ab.png'; // Update the path for the side image
import newImage from './map.png'; // Update the path for the new image
import './Home.css'; // Import the CSS file

const Home = () => (
  <Container className="mt-5">
    
    <p>Welcome to Siddhartha Bank Ltd</p>
    <img 
      src={homeImage} 
      alt="Home" 
      style={{ width: '100%', height: 'auto', borderRadius: '8px' }} // Adjust styling as needed
    />
    
    <Row className="mt-4">
      <Col md={6}>
        <div>
          <p style={{ fontSize: '1.25rem', fontWeight: 'bold' }}>OUR CUSTOMERS</p>
          <p style={{ fontSize: '1.1rem' }}>Upgrade your money. Simplify your life.</p>
          <Button variant="primary" className="custom-button">Explore</Button>
        </div>
      </Col>
      <Col md={6}>
        <div>
          <img 
            src={sideImage} 
            alt="Side" 
            style={{ width: '50%', height: 'auto', borderRadius: '8px' }} // Adjust styling as needed
          />
        </div>
      </Col>
    </Row>

    <Row className="mt-4 justify-content-center">
      <Col md={4} className="text-center">
        <Button variant="secondary" className="custom-button">Online Account</Button>
        <Button variant="secondary" className="custom-button">Online Credit Card</Button>
        <Button variant="secondary" className="custom-button">Online Dmat Account</Button>
      </Col>
    </Row>

    <Row className="mt-4">
      <Col md={8}>
        <Form.Control 
          as="textarea" 
          rows={3} 
          placeholder="Enter your question..." 
          style={{ width: '100%', borderRadius: '8px', marginBottom: '10px' }}
        />
      </Col>
      <Col md={4} className="d-flex align-items-end">
        <Button variant="primary" className="custom-button" style={{ width: '100%' }}>Submit</Button>
      </Col>
    </Row>

    <Row className="mt-4">
      <Col className="text-center">
        <img 
          src={newImage} 
          alt="New" 
          style={{ width: '100%', height: 'auto', borderRadius: '8px' }} // Adjust styling as needed
        />
      </Col>
    </Row>

    <footer>
      <div className="footer-content">
        <Row>
          <Col md={4}>
            <p>Rates Charges & Limit</p>
            <Button variant="light" className="d-block mb-2">Interest Rates</Button>
            <Button variant="light" className="d-block mb-2">Base Rate & Interest Spread Rate</Button>
            <Button variant="light" className="d-block mb-2">Standard Tariff of Charges</Button>
          </Col>
          <Col md={4}>
            <p>Forms & Download</p>
            <Button variant="light" className="d-block mb-2">Forms</Button>
            <Button variant="light" className="d-block mb-2">Calendar 2081</Button>
            <Button variant="light" className="d-block mb-2">Campaign Offers</Button>
          </Col>
          <Col md={4}>
            <p>Others</p>
            <Button variant="light" className="d-block mb-2">Cyber Security</Button>
            <Button variant="light" className="d-block mb-2">Disclaimer</Button>
            <Button variant="light" className="d-block mb-2">Book an Appointment</Button>
          </Col>
        </Row>
      </div>
    </footer>
  </Container>
);

export default Home;
