import React from 'react';
import { Container } from 'react-bootstrap';

const About = () => (
  <Container className="mt-5">
    <h1>About Page</h1>
    <p>Information about our application.</p>
  </Container>
);

export default About;
