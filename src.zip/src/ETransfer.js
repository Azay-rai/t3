// src/ETransfer.js
import React, { useState } from 'react';
import { Container, Form, Button, Table, Alert } from 'react-bootstrap';

const ETransfer = ({ accountBalances, setAccountBalances, transactionHistory, setTransactionHistory }) => {
  const [accountFrom, setAccountFrom] = useState('');
  const [accountTo, setAccountTo] = useState('');
  const [amount, setAmount] = useState('');
  const [error, setError] = useState(''); // State for error messages

  const handleTransfer = (e) => {
    e.preventDefault();
    setError(''); // Clear any previous errors

    // Validate transfer
    if (!accountFrom || !accountTo || !amount) {
      setError('All fields are required.');
      return;
    }

    const amountValue = parseFloat(amount);

    if (isNaN(amountValue) || amountValue <= 0) {
      setError('Amount must be a valid number greater than zero.');
      return;
    }

    if (!accountBalances[accountFrom]) {
      setError('Invalid source account.');
      return;
    }

    if (!accountBalances[accountTo]) {
      setError('Invalid destination account.');
      return;
    }

    if (accountBalances[accountFrom] < amountValue) {
      setError('Insufficient balance in source account.');
      return;
    }

    // Handle successful transfer
    const newBalances = { ...accountBalances };
    newBalances[accountFrom] -= amountValue;
    newBalances[accountTo] += amountValue;
    setAccountBalances(newBalances);

    // Add to history
    const newTransaction = {
      type: 'e-Transfer',
      accountFrom,
      accountTo,
      amount: amountValue,
      remainingBalance: newBalances[accountFrom],
      date: new Date().toLocaleString()
    };

    setTransactionHistory([...transactionHistory, newTransaction]);

    // Clear form fields
    setAccountFrom('');
    setAccountTo('');
    setAmount('');
  };

  return (
    <Container className="mt-5">
      <h1>e-Transfer</h1>
      {error && <Alert variant="danger">{error}</Alert>} {/* Show error message if any */}
      <Form>
        <Form.Group className="mb-3">
          <Form.Label>Account Number From</Form.Label>
          <Form.Control
            type="text"
            value={accountFrom}
            onChange={(e) => setAccountFrom(e.target.value)}
            placeholder="Enter account number from"
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Account Number To</Form.Label>
          <Form.Control
            type="text"
            value={accountTo}
            onChange={(e) => setAccountTo(e.target.value)}
            placeholder="Enter account number to"
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Amount</Form.Label>
          <Form.Control
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount"
          />
        </Form.Group>
        <Button variant="primary" onClick={handleTransfer}>Transfer</Button>
      </Form>

      {/* Transfer History */}
      <div className="mt-5">
        <h2>e-Transfer History</h2>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Date</th>
              <th>From Account</th>
              <th>To Account</th>
              <th>Amount</th>
              <th>Remaining Balance</th>
            </tr>
          </thead>
          <tbody>
            {transactionHistory
              .filter((transaction) => transaction.type === 'e-Transfer')
              .map((transfer, index) => (
                <tr key={index}>
                  <td>{transfer.date}</td>
                  <td>{transfer.accountFrom}</td>
                  <td>{transfer.accountTo}</td>
                  <td>${transfer.amount}</td>
                  <td>${transfer.remainingBalance}</td>
                </tr>
              ))}
          </tbody>
        </Table>
      </div>
    </Container>
  );
};

export default ETransfer;
