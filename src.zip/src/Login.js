import React, { useState } from 'react';
import { Container, Form, Button, Alert } from 'react-bootstrap';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState(''); // This should be the email
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    if (!username || !password) {
      setError('Username and password are required.');
      return;
    }

    try {
      // Fetching user data from JSONBin
      const response = await fetch('https://api.jsonbin.io/v3/b/66edc259e41b4d34e433f700/latest', {
        method: 'GET',
        headers: {
          'X-Master-Key': '$2a$10$ToZWzptdp8n/w6Sc1RPpyOhA34hTnX34qphoPoxBjzvGU34Ix8wJC', // Ensure you handle this securely
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }

      const binData = await response.json();
      const userFound = binData.record.find(
        (user) => user.email === username && user.password === password // Ensure you're checking the correct fields
      );

      if (userFound) {
        login(); // Call the login function
        navigate('/transactions'); // Redirect to Transactions page
      } else {
        setError('Invalid username or password.'); // Update error message
      }
    } catch (error) {
      setError('Error logging in. Please try again.'); // Update error message
    }
  };

  return (
    <Container className="mt-5">
      <h1>Login Page</h1>
      {error && <Alert variant="danger">{error}</Alert>}
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Email</Form.Label> {/* Changed to Email for clarity */}
          <Form.Control 
            type="text" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)} 
            placeholder="Enter email" 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Password</Form.Label>
          <Form.Control 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            placeholder="Password" 
          />
        </Form.Group>
        <Button variant="primary" type="submit">Login</Button>
      </Form>
    </Container>
  );
};

export default Login;
