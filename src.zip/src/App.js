import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';
import Home from './Home';
import About from './About';
import Login from './Login';
import Signup from './Signup';
import Logout from './Logout';
import Transactions from './Transactions';
import ETransfer from './ETransfer'; // Import the new component
import { AuthProvider, useAuth } from './AuthContext';
import bankLogo from './bank.jpg'; // Update the path based on where you place your image
import './App.css'; // Import your CSS file

const AppContent = () => {
  const { isAuthenticated } = useAuth();
  const [accountBalances, setAccountBalances] = useState({});
  const [transactionHistory, setTransactionHistory] = useState([]);

  const handleLoginClick = () => {
    // Logic for navigating to login
    console.log("Navigating to login");
  };

  return (
    <Router>
      <Navbar className="custom-navbar" expand="lg">
        <Container>
          <Navbar.Brand as={Link} to="/">
            <img
              src={bankLogo}
              alt="Bank Logo"
              style={{ width: '150px', height: 'auto' }} // Adjust the width as needed
            />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link as={Link} to="/">Home</Nav.Link>
              <Nav.Link as={Link} to="/about">About</Nav.Link>
              {isAuthenticated ? (
                <>
                  <Nav.Link as={Link} to="/transactions">Transactions</Nav.Link>
                  <Nav.Link as={Link} to="/etransfer">e-Transfer</Nav.Link>
                </>
              ) : (
                <>
                  <Nav.Link as={Link} to="/login">Login</Nav.Link>
                  <Nav.Link as={Link} to="/signup">Signup</Nav.Link>
                </>
              )}
              {isAuthenticated && <Nav.Link as={Link} to="/logout">Logout</Nav.Link>}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Container className="mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup handleLoginClick={handleLoginClick} />} />
          <Route path="/logout" element={<Logout />} />
          {isAuthenticated && 
            <Route 
              path="/transactions" 
              element={
                <Transactions 
                  accountBalances={accountBalances} 
                  setAccountBalances={setAccountBalances}
                  transactionHistory={transactionHistory}
                  setTransactionHistory={setTransactionHistory}
                />
              }
            />
          }
          {isAuthenticated && 
            <Route 
              path="/etransfer" 
              element={
                <ETransfer 
                  accountBalances={accountBalances} 
                  setAccountBalances={setAccountBalances}
                  transactionHistory={transactionHistory}
                  setTransactionHistory={setTransactionHistory}
                />
              }
            />
          }
        </Routes>
      </Container>
    </Router>
  );
};

const App = () => (
  <AuthProvider>
    <AppContent />
  </AuthProvider>
);

export default App;
