// src/Transactions.js
import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Row, Col, ListGroup } from 'react-bootstrap';

const Transactions = ({ accountBalances, setAccountBalances, userEmail }) => {
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  const [transactionHistory, setTransactionHistory] = useState([]);

  const API_URL = `https://api.jsonbin.io/v3/b/66f320dce41b4d34e4366d94`;
  const API_KEY = '$2a$10$ToZWzptdp8n/w6Sc1RPpyOhA34hTnX34qphoPoxBjzvGU34Ix8wJC';

  useEffect(() => {
    // Fetch transaction history for the logged-in user on component mount
    const fetchTransactionHistory = async () => {
      try {
        const response = await fetch(API_URL, {
          headers: {
            'X-Master-Key': API_KEY,
          },
        });
        const data = await response.json();
        // Filter to only include transactions for the current user's email
        const userTransactions = data.transactions || [];
        setTransactionHistory(userTransactions.filter(transaction => transaction.email === userEmail));
      } catch (error) {
        console.error('Failed to fetch transaction history', error);
      }
    };

    fetchTransactionHistory();
  }, [userEmail]); // Dependency on userEmail to refetch if it changes

  const updateTransactionHistory = async (newTransaction) => {
    try {
      const response = await fetch(API_URL, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': API_KEY,
        },
        body: JSON.stringify({
          transactions: [...transactionHistory, newTransaction] // Append new transaction
        }),
      });
      if (!response.ok) {
        throw new Error('Failed to update transaction history');
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleWithdraw = async (e) => {
    e.preventDefault();
    if (withdrawAmount) {
      const amount = parseFloat(withdrawAmount);
      const currentBalance = getCurrentBalance(); // Calculate current balance

      if (currentBalance >= amount) {
        const transaction = {
          email: userEmail, // Include email in the transaction object
          amount: amount, // Store amount as a number
          type: 'Withdraw',
          date: new Date().toLocaleString() // Current date and time
        };
        await updateTransactionHistory(transaction); // Update transaction history in JSONBin
        setWithdrawAmount(''); // Clear the input field after submission
        setTransactionHistory(prev => [...prev, transaction]); // Update local transaction history without overwriting
      } else {
        console.log('Insufficient funds or invalid account');
      }
    }
  };

  const handleDeposit = async (e) => {
    e.preventDefault();
    if (depositAmount) {
      const amount = parseFloat(depositAmount);
      const transaction = {
        email: userEmail, // Include email in the transaction object
        amount: amount, // Store amount as a number
        type: 'Deposit',
        date: new Date().toLocaleString() // Current date and time
      };
      await updateTransactionHistory(transaction); // Update transaction history in JSONBin
      setDepositAmount(''); // Clear the input field after submission
      setTransactionHistory(prev => [...prev, transaction]); // Update local transaction history without overwriting
    } else {
      console.log('Invalid deposit request');
    }
  };

  const handleCancel = () => {
    setWithdrawAmount('');
    setDepositAmount('');
  };

  const getCurrentBalance = () => {
    // Calculate the current balance based on transaction history
    return transactionHistory.reduce((balance, transaction) => {
      return transaction.type === 'Deposit'
        ? balance + transaction.amount
        : balance - transaction.amount;
    }, 0);
  };

  const currentBalance = getCurrentBalance(); // Get the calculated current balance

  return (
    <Container className="mt-5">
      <h1>Transactions</h1>
      <Row>
        <Col md={6}>
          <h2>Withdraw Funds</h2>
          <Form onSubmit={handleWithdraw}>
            <Form.Group className="mb-3">
              <Form.Label>Amount</Form.Label>
              <Form.Control 
                type="number" 
                value={withdrawAmount} 
                onChange={(e) => setWithdrawAmount(e.target.value)} 
                placeholder="Enter amount to withdraw" 
              />
            </Form.Group>
            <Button variant="primary" type="submit">Withdraw</Button>
            <Button variant="secondary" onClick={handleCancel} className="ml-2">Cancel</Button>
          </Form>
        </Col>
        <Col md={6}>
          <h2>Deposit Funds</h2>
          <Form onSubmit={handleDeposit}>
            <Form.Group className="mb-3">
              <Form.Label>Amount</Form.Label>
              <Form.Control 
                type="number" 
                value={depositAmount} 
                onChange={(e) => setDepositAmount(e.target.value)} 
                placeholder="Enter amount to deposit" 
              />
            </Form.Group>
            <Button variant="primary" type="submit">Deposit</Button>
            <Button variant="secondary" onClick={handleCancel} className="ml-2">Cancel</Button>
          </Form>
        </Col>
      </Row>
      <Row className="mt-5">
        <Col>
          <h2>Transaction History</h2>
          <ListGroup>
            {transactionHistory.map((transaction, index) => (
              <ListGroup.Item key={index}>
                {transaction.type} - Amount: ${transaction.amount}, Date: {transaction.date}, Email: {transaction.email}
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Col>
        <Col>
          <h2>Current Balance</h2>
          <p>${currentBalance.toFixed(2)}</p>
        </Col>
      </Row>
    </Container>
  );
};

export default Transactions;
